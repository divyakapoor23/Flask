from flask import Flask, render_template,redirect, session, request
import random
app = Flask(__name__)
app.secret_key="Ninja Gold"


@app.route("/")
def ninja():
    #if this is the first time the user is playing ninja gold, give them an empty session
    if "mygold" not in session:
        session["mygold"] = 0
    return render_template("ninjagold.html", mygold = session["mygold"])


@app.route("/process_gold", methods=["POST"])
def process_gold():
    print(20*"***********************")
    if request.form["location"] =="farm":
        print("I am at the farm")
        randomGold = random.randint(10, 20)
        session["mygold"]+=randomGold
    if request.form["location"] =="cave":
        print("I am at the cave")
        randomGold = random.randint(5, 10)
        session["mygold"]+=randomGold
    if request.form["location"] =="house":
        print("I am at the house")
        randomGold = random.randint(2, 5)
        session["mygold"]+=randomGold
    if request.form["location"] =="casino":
        print("I am at the casino")
        trueOrFalseToggle = random.randint(0, 1)
        print (trueOrFalseToggle)
        randomGold = random.randint(0, 50)
        if trueOrFalseToggle == 1:
            session["mygold"]-=randomGold
        else:
            session["mygold"]+=randomGold

    return redirect("/")

@app.route("/reset")
def reset():
    if "mygold" in session:
        session["mygold"] = 0
        return redirect("/")
    # else:
    #     return("Please play the game")

if __name__=="__main__":
    app.run(debug=True)


#name defines the key value in the html and the name must be same for all of the different values