from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def dictionary():
    users_info = [
        {'First Name' : 'Michael', 'Last Name' : 'Choi', 'Full Name' : 'Michael Choi'},
        {'First Name' : 'John', 'Last Name' : 'Supsupin', 'Full Name' : 'John Supsupin'},
        {'First Name' : 'Mark', 'Last Name' : 'Guilen', 'Full Name' : 'Mark Guilen'},
    ]
    return render_template("list.html", people = users_info)

if __name__ =="__main__":
    app.run(debug=True)