from flask import Flask, render_template, redirect, session, request
import random

app = Flask(__name__)
app.secret_key = "Great Number Game"

@app.route("/")
def numgame():
    if "alert" not in session:
        session["alert"] = ""
    if "num" not in session:
        session["num"] = random.randint(1, 100)
    return render_template("numgame.html", message=session["alert"])


@app.route("/guess", methods=["POST"])
def guess():
    num = int(request.form["num"])
    if num==session["num"]:
        session["alert"] = "You guessed the right number"
    elif num<session["num"]:
        session["alert"] = "Too high guess lower"
    elif num>session["num"]:
        session["alert"] = "Too low guess higher"
    return redirect("/")

@app.route("/reset")
def reset():
    if "num" not in session:
        session.pop["num"]
    if "alert" not in session:
        session["alert"] = ""

if __name__=="__main__":
    app.run(debug=True)


